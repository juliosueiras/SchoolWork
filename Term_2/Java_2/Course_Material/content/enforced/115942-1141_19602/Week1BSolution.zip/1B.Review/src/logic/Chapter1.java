/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 * This class contains some basic algorithms which you learned in PROG10082
 * 
 * @author Mats Swan
 * @since Jan 8, 2014
 * @version 1.0
 */
public class Chapter1 {

    /**
     * This method prints a small table of radii of circles, their respective areas, and perimeters
     * 
     * @since Jan 8, 2014
     */
    public void run() {
        double pi = 3.14;  // <-- you can use Math.PI instead.
        double area, radius, perimeter;
        
        System.out.println("Radius\tArea\tPerimeter");
        System.out.println("------\t----\t---------");
        
        for(radius = 1.0; radius < 6.0; radius++) {
            System.out.printf("%.1f\t", radius);
            area = Math.PI * (radius * radius);
            System.out.printf("%.2f\t", area);
            perimeter = Math.PI * 2 * radius;
            System.out.printf("%.2f\n", perimeter);
        }
    }
    
    
    
}
