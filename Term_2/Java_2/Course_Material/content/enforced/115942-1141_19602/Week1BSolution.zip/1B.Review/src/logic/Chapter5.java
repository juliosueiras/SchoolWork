/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

import java.util.Scanner;

/**
 * A simple class to review Chapter 3 of PROG10082: Java I
 *
 * @author Mats Swan
 * @version 1.0
 * @since Jan 8, 2014
 */
public class Chapter5 {

    /**
     * This method computes the sum of the digits in an integer
     * 
     * @since Jan 8, 2014
     */
    public void run() {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Calculate which number? ");
        long evaluate = input.nextLong();
        
        int value = Calculator.sumDigits(evaluate);
        System.out.println("\nThe sum of the digits in " + evaluate + " is " + value);
    }
    
}
