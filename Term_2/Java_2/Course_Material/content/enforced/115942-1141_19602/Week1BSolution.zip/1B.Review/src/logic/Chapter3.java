/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

import java.util.Scanner;

/**
 * A simple class to review Chapter 3 of PROG10082: Java I
 * 
 * @author Mats Swan
 * @version 1.0
 * @since Jan 8, 2014
 */
public class Chapter3 {

    /**
     * When you run this method, it will calculate a user's BMI based on the input
     * of height and weight
     * 
     * @since Jan 8, 2014
     * 
     */
    public void run() {
        Scanner in = new Scanner(System.in);
        double weight, bmi;
        int heightInFeet, heightInInches, totalHeight;
        
        System.out.print("Please enter your weight: ");
        weight = in.nextDouble();
        in.nextLine();
        
        System.out.print("Please enter your height (in feet):  ");
        heightInFeet = in.nextInt();
        in.nextLine();
        
        System.out.print("Please enter your height (in inches):  ");
        heightInInches = in.nextInt();
        in.nextLine();
        
        totalHeight = (heightInFeet * 12) + heightInInches;
        bmi = (weight / Math.pow(totalHeight, 2)) * 703;
                
        System.out.printf("Your BMI is: %.2f\n", bmi);
                
        String results = "== Unable to locate results ==";
        if(bmi > 0.0 && bmi < 18.0)
            results = "underweight";
        else if(bmi <= 18.5)
            results = "thin for height";
        else if(bmi < 25.0)
            results = "healthy";
        else if(bmi < 30.0)
            results = "overweight";
        else 
            results = "obese";
        
        System.out.println("Your BMI suggests that you are " + results);
        
    }
    
}
