/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import java.util.Scanner;

/**
 * This class contains some basic algorithms which you learned in PROG10082
 * 
 * @author Mats Swan
 * @since Jan 8, 2014
 * @version 1.0
 */
public class Chapter2 {

    /**
     * This method calculates the tip and total on a bill
     * 
     * @since Jan 8, 2014
     */
    public void run() {
        Scanner in = new Scanner(System.in);
        String another = "n";
        do {
            System.out.print("What was the value of the cheque? ");
            double bill = in.nextDouble();
            in.nextLine();

            // more effective to do with a for loop
            System.out.println("\nService\t\tTip %\tTip Amount\tTotal");
            System.out.println("-------\t\t-----\t----------\t-----");
            System.out.printf("%-7s\t\t%-5s\t$%-10.2f\t$%-5.2f\n", "Poor", "5%", bill * .05, bill * 1.05);
            System.out.printf("%-7s\t\t%-5s\t$%-10.2f\t$%-5.2f\n", "Average", "10%", bill * .1, bill * 1.1);
            System.out.printf("%-7s\t\t%-5s\t$%-10.2f\t$%-5.2f\n", "Good", "15%", bill * .15, bill * 1.15);
            System.out.printf("%-7s\t\t%-5s\t$%-10.2f\t$%-5.2f\n", "Great", "18%", bill * .18, bill * 1.18);
            System.out.printf("%-7s\t%-5s\t$%-10.2f\t$%-5.2f\n", "Excellent", "20%", bill * .2, bill * 1.2);

            System.out.print("Would you like to do another? (y/n)");
            another = in.nextLine();
        } while (another.equalsIgnoreCase("y"));
    }

}
