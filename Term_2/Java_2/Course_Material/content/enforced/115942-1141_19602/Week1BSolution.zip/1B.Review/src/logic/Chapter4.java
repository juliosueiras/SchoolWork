/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import java.util.Scanner;

/**
 * A simple class to review Chapter 3 of PROG10082: Java I
 *
 * @author Mats Swan
 * @version 1.0
 * @since Jan 8, 2014
 */
public class Chapter4 {

    /**
     * When you run this method, it prompts the user for the number of students
     * and their grades, then displays the student with the best and second-best
     * records
     * 
     * @since Jan 8, 2014
     */
    public void run() {
        Scanner input = new Scanner(System.in);
        System.out.print("How many students would you like to evaluate? ");
        int numStudents = input.nextInt();
        input.nextLine();

        String studentName = "";
        double studentGrade = 0.0;

        String bestStudent = "No one!", secondBestStudent = "No one!";
        double bestGrade = 0.0, secondBestGrade = 0.0;

        System.out.println("...evaluating " + numStudents + " students...");
        for (int i = 1; i <= numStudents; i++) {
            System.out.print("Type in Student " + i + "'s name: ");
            studentName = input.nextLine();

            System.out.print("Type in " + studentName + "'s grade: ");
            studentGrade = input.nextDouble();
            input.nextLine();

            if (studentGrade >= bestGrade) {
                bestGrade = studentGrade;
                bestStudent = studentName;
            } else if (studentGrade >= secondBestGrade) {
                secondBestGrade = studentGrade;
                secondBestStudent = studentName;
            }
        }
        System.out.println("\nThe best student is " + bestStudent + " (" + bestGrade + ")");
        System.out.println("The next best student is " + secondBestStudent + " (" + secondBestGrade + ")");
    }

}
