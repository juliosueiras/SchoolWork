/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runtime;

import logic.*;

/**
 *
 * @author Mats Swan
 */
public class Review {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Chapter1 review = new Chapter1();
//        Chapter2 review = new Chapter2();
//        Chapter3 review = new Chapter3();
//        Chapter4 review = new Chapter4();
//        Chapter5 review = new Chapter5();
        Chapter6 review = new Chapter6();
        review.run();
        
    }

}
