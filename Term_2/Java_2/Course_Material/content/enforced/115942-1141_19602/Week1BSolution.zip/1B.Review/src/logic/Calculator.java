/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 * The calculator class handles mathematical algorithms
 * 
 * @author Mats Swan
 * @version 1.0
 * @since 08-Jan-14
 */
public class Calculator {

    /**
     * The method accepts a long integer and returns the sum of its individual digits as an integer.
     * 
     * @param n: represents the long integer
     * @return the sum of the digits of the long
     */
    public static int sumDigits(long n) {
        int result = 0, digit = 0;
        String nAsString = String.valueOf(n);  // convert the long to a string to count the number of digits
        
        // Step 1: start with the length of the long, that's the number of digits to iterate...
        for(int i = nAsString.length() - 1; i >= 0; i--) {
            
            // Step 2: divide the long by a factor of 10 to extract the single digit
            digit = (int) (n / Math.pow(10, i));
            
            // Step 3: remove that digit from the front
            n -= (digit * Math.pow(10, i));
            
            // Step 4: tally that digit to the result
            result += digit;
        }
        
        return result;
    }
    
}
