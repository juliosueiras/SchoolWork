/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import java.util.Scanner;

/**
 * A simple class to review Chapter 3 of PROG10082: Java I
 *
 * @author Mats Swan
 * @version 1.0
 * @since Jan 8, 2014
 */
public class Chapter6 {

    /**
     * This method reads in student grades from the console, gets the best
     * grade, and assigns a letter grade based on the Sheridan letter grading
     * scheme
     *
     * @since 08-Jan-14
     */
    public void run() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of students: ");
        int numStudents = input.nextInt();
        input.nextLine();

        if (numStudents < 1) {
            System.out.println("Ha ha, very funny, you know I can't do that.");
            System.exit(1);
        } else if (numStudents == 1) {
            System.out.print("Enter the student score: ");
        } else {
            System.out.print("Enter the " + numStudents + " scores: ");
        }

        double[] scoreSet = new double[numStudents];

        for (int i = 0; i < numStudents; i++) {
            scoreSet[i] = input.nextDouble();
        }

        System.out.println("\nResults");
        System.out.println("-------");

        for (int i = 1; i < numStudents + 1; i++) {
            System.out.println("Student " + i + " score: " + scoreSet[i - 1] + ", grade " + letterGrade(scoreSet[i - 1]));
        }
    }

    /**
     * This method converts a grade percentage in to a letter grade using the current Sheridan scheme
     * 
     * @param i: the student's grade as a percentage
     * @return a letter grade
     * @since 08-Jan-14
     */
    private String letterGrade(double i) {
        String finalGrade = "F";
        if (i >= 50 && i < 60) {
            finalGrade = "D";
        } else if(i >= 60 && i < 65) {
            finalGrade = "C";
        } else if(i >= 65 && i < 70) {
            finalGrade = "C+";
        }else if(i >= 70 && i < 75) {
            finalGrade = "B";
        }else if(i >= 75 && i < 80) {
            finalGrade = "B+";
        }else if(i >= 80 && i < 90) {
            finalGrade = "A";
        }else if (i >= 90) {
            finalGrade = "A+";
        }
        return finalGrade;
    }

}

