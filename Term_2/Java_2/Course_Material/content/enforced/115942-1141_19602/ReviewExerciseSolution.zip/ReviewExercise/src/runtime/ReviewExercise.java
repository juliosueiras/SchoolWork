package runtime;

import logic.*;

/**
 * This is a generic runtime class for testing the two exercise classes:
 * CreditCardBalance and TFQuestion
 *
 * @author Mats Swan
 * @version 1.0
 * @since 09-JAN-14
 * @see CreditCardBalance, TriviaGame
 */
public class ReviewExercise {

    /**
     * Instantiates the test class(es) and executes them. Comment out the test
     * class you do not wish to execute
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        CreditCardBalance test = new CreditCardBalance();
        TriviaGame test = new TriviaGame();
        test.run();
    }

}
