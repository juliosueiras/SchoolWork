package logic;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * *
 * This class was part of the week one review exercise. The purpose of this
 * class is to read in a customer's credit card balance and interest rate, then
 * calculate the minimum monthly payment due for the next 12 months, assuming
 * that the customer makes the minimum monthly payment each month.
 *
 * @author Mats Swan
 * @version 1.0
 * @since 09-JAN-14
 * @see ReviewExercise
 */
public class CreditCardBalance {

    private final static double MIN_PAY_PERCENTAGE = 0.03;
    private final static double MIN_PAY_AMOUNT = 10.0;

    public void run() {
        Scanner inUserInput = new Scanner(System.in);
        double dCardBalance = 0.0, dInterestRate = 0.0, dMinPayment;

        while (true) {
            try {
                System.out.print("Enter credit card balance: ");
                dCardBalance = inUserInput.nextDouble();
                inUserInput.nextLine();

                System.out.print("Enter interest rate: ");
                dInterestRate = inUserInput.nextDouble();
                inUserInput.nextLine();
            } catch (InputMismatchException imx) {                              // handles non-numeric entries                
                System.out.println("==> I'm sorry, you must enter a valid number.\n");
                inUserInput.nextLine();
                continue;                                                       // skip the rest of this iteration            
            }

            if (dCardBalance < 0.0 || dInterestRate <= 0.0) {                   // check if the balance and interest are valid                
                System.out.println("==> Please enter a balance greater than or "
                        + "equal to 0, and an interest rate greater than 0\n");
            } else {
                break;
            }
        }
        System.out.printf("\n%15s%18s\n", "Min Pmt", "New Balance");            // prints Min Pmt and New Balance as headers centred over table        
        System.out.println("=====================================");

        // print statement left formats numbers in an 8-size and two 15-size columns
        for (int i = 1; i <= 12; i++) {
            dCardBalance += dCardBalance * (dInterestRate / 100);               // Balance is multiplied by interest expressed as percentage            
            dMinPayment = calculateMinPayment(dCardBalance);                    // use formula to calculate minimum payment            
            dCardBalance -= dMinPayment;                                        // deduct minimum payment from balance
            System.out.printf("%-8s$%-15.2f$%-15.2f\n", i + ":", dMinPayment, dCardBalance);
        }

    }
    
   /**
    * This method calculates the minimum payment that is due. The minimum
    * payment is either $10.00 or 3% of the balance, whichever is more,
    * unless, of course, the balance is already less than $10.00, in which
    * case, the full amount is due.
    *
    * @param dBalance the credit card balance
    * @return the minimum payment amount *
    */
    public double calculateMinPayment(double dBalance) {
        double dMinimum = dBalance * MIN_PAY_PERCENTAGE;                        // assume that the minimum is 3% of balance        
        if (dMinimum < MIN_PAY_AMOUNT) {                                        // if 3% of the balance is less than $10.00            
            if (MIN_PAY_AMOUNT > dBalance) {                                    // and if the balance is less than $10.00             
                dMinimum = dBalance;                                            // the minimum due is the balance            
            } else {
                dMinimum = MIN_PAY_AMOUNT;                                      // otherwise the minimum due is $10.00             
            }
        }
        return dMinimum;
    }

}
