package logic;

/**
 * This class represents a true or false question for the TriviaGame class
 * 
 * @author Mats Swan
 * @version 1.0
 * @see ReviewExercise
 */
public class TFQuestion {
    private int questionId;
    private String questionText;
    private boolean answer;

    /**
     * A constructor for the class
     *     
     * @param questionId the question's ID
     * @param questionText the question phrase
     * @param answer the valid response as a boolean
     */
    public TFQuestion(int questionId, String questionText, boolean answer) {
        this.questionId = questionId;
        this.questionText = questionText;
        this.answer = answer;
    }

    /**
     * A mutator method for the question ID field
     *     
     * @param questionId the ID field
     * @throws IllegalArgumentException if the ID field is invalid
     */
    public void setQuestionId(int questionId) throws IllegalArgumentException {
        try {
            this.questionId = questionId;
        } catch (IllegalArgumentException e) {
            System.out.println("Illegal argument: " + questionId + 
                    " is not an appropriate integer value for the question ID");
        }
    }

    /**
     * A mutator method for the question text field
     *     
     * @param questionText the question
     * @throws IllegalArgumentException if the question text is invalid
     */
    public void setQuestionText(String questionText) throws IllegalArgumentException {
        try {
            this.questionText = questionText;
        } catch (IllegalArgumentException e) {
            System.out.println("Illegal argument: " + questionText + 
                    " is not an appropriate string value for the question text");
        }
    }

    /**
     * A mutator method for the answer field
     *     
     * @param answer the question's answer as a boolean
     * @throws IllegalArgumentException if it's not a valid boolean
     */
    public void setAnswer(boolean answer) throws IllegalArgumentException {
        try {
            this.answer = answer;
        } catch (IllegalArgumentException e) {
            System.out.println("Illegal argument: " + answer + 
                    " is not an appropriate boolean value for the answer");
        }
    }

    /**
     * An accessor for the question ID field
     *     
     * @return the question ID field
     */
    public int getQuestionId() {
        return questionId;
    }

    /**
     * An accessor for the questionText field
     *     
     * @return the question text field
     */
    public String getQuestionText() {
        return questionText;
    }

    /**
     * An accessor for the answer field
     *     
     * @return the answer field
     */
    public boolean getAnswer() {
        return answer;
    }

    /**
     * Determines if the user's guess was correct
     *     
     * @param guess the user's guess
     * @return a response indicating success
     */
    public boolean isCorrect(boolean guess) {
        return guess == getAnswer() ? true : false;
    }

    /**
     * Prints the question as a string
     *     
     * @return a String representation of the question
     */
    public String toString() {
        return ("#" + getQuestionId() + ":  True / False :  " + getQuestionText());
    }

}
