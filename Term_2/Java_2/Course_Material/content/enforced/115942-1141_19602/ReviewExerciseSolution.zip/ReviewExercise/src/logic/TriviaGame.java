package logic;

import java.util.Scanner;

/**
 * This class tests the True and False question class with a series of trivia
 * questions
 * 
 * @author Mats Swan
 * @version 1.0
 * @since 09-JAN-14
 * @see TFQuestion
 */
public class TriviaGame {

    public void run() {

        TFQuestion trivia[] = new TFQuestion[5];                                // store the questions in an array                
        trivia[0] = new TFQuestion(1, "Green Lantern is Hal Jordan.", true);
        trivia[1] = new TFQuestion(2, "Peter Parker is Batman.", false);
        trivia[2] = new TFQuestion(3, "Barry Allen is the Flash.", true);
        trivia[3] = new TFQuestion(4, "Bruce Banner is Spider-Man.", false);
        trivia[4] = new TFQuestion(5, "Matt reads too many comic books.", true);

        Scanner inUserInput = new Scanner(System.in);

        for (int i = 0; i < 5; i++) {                                             // iterate through the array            
            System.out.println(trivia[i].toString());                           // prints the question            
            if (trivia[i].isCorrect(inUserInput.nextBoolean())) // evaluates the user's boolean response against the question to see if it's correct
            {
                System.out.println("==> That's correct!\n");
            } else {
                System.out.println("==> I'm sorry, that's wrong.\n");
            }
            inUserInput.nextLine();
        }
    }
}
