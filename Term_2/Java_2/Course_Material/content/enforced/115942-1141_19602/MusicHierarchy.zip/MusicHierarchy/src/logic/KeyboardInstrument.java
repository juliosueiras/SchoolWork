/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class KeyboardInstrument extends Instrument implements Electric {
    private int keys;
    private int levels;
    
    @Override
    public void amplifier() {
        System.out.println("Keyboard >>> Amplifier set low");
    }

    @Override
    public boolean pedals() {
        System.out.println("Keyboard >>> dampen or mute sound");
        return true;
    }

    public int getKeys() {
        return keys;
    }

    public void setKeys(int keys) {
        this.keys = keys;
    }

    public int getLevels() {
        return levels;
    }

    public void setLevels(int levels) {
        this.levels = levels;
    }
    
}
