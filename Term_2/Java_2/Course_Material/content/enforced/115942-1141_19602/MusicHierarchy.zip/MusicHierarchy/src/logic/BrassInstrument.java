/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class BrassInstrument extends Instrument {
    private int mouthpiece;
    private double lengthOfTubes;

    public int getMouthpiece() {
        return mouthpiece;
    }

    public void setMouthpiece(int mouthpiece) {
        this.mouthpiece = mouthpiece;
    }

    public double getLengthOfTubes() {
        return lengthOfTubes;
    }

    public void setLengthOfTubes(double lengthOfTubes) {
        this.lengthOfTubes = lengthOfTubes;
    }
}
