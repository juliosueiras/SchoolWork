/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class StringInstrument extends Instrument implements Electric {
    private double[] guage;
    private int numStrings;
    private boolean bow;

    public double[] getGuage() {
        return guage;
    }

    public void setGuage(double[] guage) {
        this.guage = guage;
    }

    public int getNumStrings() {
        return numStrings;
    }

    public void setNumStrings(int numStrings) {
        this.numStrings = numStrings;
    }

    public boolean isBow() {
        return bow;
    }

    public void setBow(boolean bow) {
        this.bow = bow;
    }

    @Override
    public void amplifier() {
        System.out.println("String >>>> Amplifier goes to 11");
    }

    @Override
    public boolean pedals() {
        System.out.println("Strings >>> pedals change sound");
        return true;
    }
}
