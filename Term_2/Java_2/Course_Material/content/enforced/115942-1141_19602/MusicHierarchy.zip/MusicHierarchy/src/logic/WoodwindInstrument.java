/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class WoodwindInstrument extends Instrument {
    private boolean reed;

    public boolean hasReed() {
        return reed;
    }

    public void setReed(boolean reed) {
        this.reed = reed;
    }
}
