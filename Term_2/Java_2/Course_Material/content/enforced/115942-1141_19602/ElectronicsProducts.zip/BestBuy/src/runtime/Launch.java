/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package runtime;

import java.util.logging.Level;
import java.util.logging.Logger;
import logic.*;
import logic.err.InvalidDimensionsException;

/**
 *
 * @author Mats Swan
 */
public class Launch {

    private static int counter = 0;
    private static Electronics[] shoppingCart = new Electronics[3];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // These are actual products that I found on BestBuy.ca
            Electronics aCamera = new Camera();
            aCamera.setMake("Olympus");
            aCamera.setModel("SP-82OUZ");
            aCamera.setName("Optical Zoom Digital Camera - Silver");
            aCamera.setPrice(169.99);
            aCamera.setDimensions(7.3, 10.7, 7.3);
            // The 'aCamera' variable is of the parent class, Electronics, so it
            // must be cast to a Camera class before I can set megapixels
            ((Camera)aCamera).setMegaPixels(12);
            
            Electronics aPrinter = new Printer();
            aPrinter.setMake("Brother");
            aPrinter.setModel("HL-2270DW");
            aPrinter.setName("Wireless Laser Printer");
            aPrinter.setPrice(99.99);
            aPrinter.setDimensions(36, 36.8, 18.3);
            ((Printer) aPrinter).setPagesPerMinute(120);
            
            Electronics aTelevision = new Television();
            aTelevision.setMake("Insignia");
            aTelevision.setModel("NS-55D440NA14");
            aTelevision.setName("1080p 120hz LED HDTV");
            aTelevision.setPrice(599.99);
            aTelevision.setDimensions(29.5, 49.1, 3.4);
            ((Television)aTelevision).setResolution("1920x1080p");
            
            // Add the items to the shopping cart
            shoppingCart[0] = aCamera;
            shoppingCart[1] = aPrinter;
            shoppingCart[2] = aTelevision;
            
            // Get the items from the cart and print them
            System.out.println("Your shopping cart contains");
            System.out.println("===========================");
            
            for(int i = 0; i < shoppingCart.length; i++) {
                System.out.print(shoppingCart[i].getClass().getName() + ": ");
                System.out.print(shoppingCart[i].getMake() + " " +
                        shoppingCart[i].getModel() + " " +
                        shoppingCart[i].getName() + "\n");
                
                if(shoppingCart[i] instanceof Camera) {
                    System.out.println("\tMegapixels: " + ((Camera)shoppingCart[i]).getMegaPixels());
                } else if(shoppingCart[i] instanceof Printer) {
                    System.out.println("\tPPM: " + ((Printer)shoppingCart[i]).getPagesPerMinute());
                } else if(shoppingCart[i] instanceof Television) {
                    System.out.println("\tResolution: " + ((Television) shoppingCart[i]).getResolutionAsString());
                    // If this is a TV, size is represented differently. 
                    // getSize() was overridden in the Television class
                    System.out.printf("\tSize: %.0f\"\n" , Double.parseDouble(((Television) shoppingCart[i]).getSize()));
                    continue;
                }
                // This is the default getSize() method, written in the Electronics class
                System.out.println("\tSize: " + shoppingCart[i].getSize());
            }
        } catch (InvalidDimensionsException ex) {
            System.err.println("ERROR: " + ex.getMessage());
            System.exit(1);
        }
    }
    
}
