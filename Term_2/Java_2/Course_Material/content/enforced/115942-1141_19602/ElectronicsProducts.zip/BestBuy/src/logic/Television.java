/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

import logic.err.InvalidDimensionsException;

/**
 *
 * @author Mats Swan
 */
public class Television extends Electronics {
    private boolean threeDimensional;
    private boolean highDefinition;
    private int[] resolution = new int[2];
    private int refreshRate;
    private boolean hdmiCompatible;
    private boolean usbCompatible;
    private String pictureType;

    public boolean isThreeDimensional() {
        return threeDimensional;
    }

    public void setThreeDimensional(boolean threeDimensional) {
        this.threeDimensional = threeDimensional;
    }

    public boolean isHighDefinition() {
        return highDefinition;
    }

    public void setHighDefinition(boolean highDefinition) {
        this.highDefinition = highDefinition;
    }

    /**
     * Gets the picture resolution written in pixels as a String.
     * 
     * @return String resolution
     */
    public String getResolutionAsString() {
        return resolution[0] + "x" + resolution[1] + "p";
    }
    
    public int[] getResolution() {
        return resolution;
    }

    public void setResolution(int[] resolution) {
        this.resolution = resolution;
    }
    
    /**
     * Sets the picture resolution as two integer values when entered as a String
     * 
     * @param resolutionInPixels e.g., "1920x1080p"
     */
    public void setResolution(String resolutionInPixels) throws InvalidDimensionsException {
        String[] pixelValues = resolutionInPixels.trim().toLowerCase().split("[a-z]");
        if(pixelValues.length != 2){
            throw new InvalidDimensionsException("Television resolution must be written as a pixel pair (eg, 1920x1080p)");
        } else {
            resolution[0] = Integer.parseInt(pixelValues[0]);
            resolution[1] = Integer.parseInt(pixelValues[1]);
        }
    }

    public int getRefreshRate() {
        return refreshRate;
    }

    public void setRefreshRate(int refreshRate) {
        this.refreshRate = refreshRate;
    }

    public boolean isHdmiCompatible() {
        return hdmiCompatible;
    }

    public void setHdmiCompatible(boolean hdmiCompatible) {
        this.hdmiCompatible = hdmiCompatible;
    }

    public boolean isUsbCompatible() {
        return usbCompatible;
    }

    public void setUsbCompatible(boolean usbCompatible) {
        this.usbCompatible = usbCompatible;
    }

    public String getPictureType() {
        return pictureType;
    }

    public void setPictureType(String pictureType) {
        this.pictureType = pictureType;
    }

    @Override
    public String getSize() {
        // Television size is measured diagonally across the front of the screen
        // Use the Pythagorean formula to calculate diagonal size (a^2 + b^2 = c^2)
        return Double.toString(Math.sqrt(Math.pow(getHeight(),2) + Math.pow(getWidth(), 2)));
    }
    
    
}
