/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import logic.err.InvalidDimensionsException;

/**
 *
 * @author Mats Swan
 */
public class Electronics {

    private double price;
    private String productCode;
    private String description;
    private double rating;
    private boolean available;
    private String make;
    private String model;
    private String name;
    private double height = 0.0, length = 0.0, width = 0.0;

    public void setDimensions(double ht, double wd, double ln) {
        setHeight(ht);
        setLength(ln);
        setWidth(wd);
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * This is the default size: the dimensions of the product
     *
     * @return a String representing height x width x length (eg, 14 x 8 x 12)
     */
    public String getSize() {
        return getHeight() + " x " + getWidth() + " x " + getLength();
    }

    public void setSize(String size) throws InvalidDimensionsException {
        // Get the dimensions as an array of three numbers.
        String[] dimensions = size.trim().toLowerCase().split("[a-z]");
        /* 
            Here's what that line of code does:
            Input           Method      Function            Result (data type)
            =====           ======      ========            ==================
        1.  10 X 9 X 11     trim()      removes whitespace  10X9X11
        2.  10X9X11         toLowerCase to lower case       10x9x11
        3.  10x9x11         split       creates arrays      [10,9,11]
        Result: [10,9,11]
        About split(): split creates an array of strings based on a delimiter
        The delimiter is expressed as a Regular Expression (http://www.regular-expressions.info)
        [a-z] means "any alphabet character between lower case a and z"
        Therefore, any letter (eg, x), delimits or separates the values
        
        */
        if (dimensions.length != 3) {
            throw new InvalidDimensionsException("The item must express size as 'height x width x length'");
        } else {
            setHeight(Double.parseDouble(dimensions[0]));
            setWidth(Double.parseDouble(dimensions[1]));
            setLength(Double.parseDouble(dimensions[2]));
        }
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
