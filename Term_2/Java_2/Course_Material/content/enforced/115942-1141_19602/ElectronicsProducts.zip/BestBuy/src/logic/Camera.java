/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class Camera extends Electronics {
    private boolean interchangeableLens;
    private int megaPixels;
    private String storageType;
    private boolean singleLensReflex;

    public boolean hasInterchangeableLens() {
        return interchangeableLens;
    }

    public void setInterchangeableLens(boolean interchangeableLens) {
        this.interchangeableLens = interchangeableLens;
    }

    public int getMegaPixels() {
        return megaPixels;
    }

    public void setMegaPixels(int megaPixels) {
        this.megaPixels = megaPixels;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

    public boolean isSingleLensReflex() {
        return singleLensReflex;
    }

    public void setSingleLensReflex(boolean singleLensReflex) {
        this.singleLensReflex = singleLensReflex;
    }
    
    /**
     * getSize() will return the height, width, length dimensions
     * setSize() requires dimensions to be expressed as a String '6.5 x 2.2 x 3.8'
     */
}
