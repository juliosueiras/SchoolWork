/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

/**
 *
 * @author Mats Swan
 */
public abstract class FruitFarmer extends ProduceFarmer {

    @Override
    public void water() {
        System.out.println("FruitFarmer >>> I'm Fruit Farmer " + getName() + ".  I water fruit by using a large sprayer.");
    }

    @Override
    public void harvest() {
        System.out.println("FruitFarmer >>> I'm a Fruit Farmer.  I harvest fruit by picking it by hand.");
    }

    @Override
    public void rain() {
        super.rain();
        System.out.println("FruitFarmer >>> It's raining, double good: more water means bigger fruit");

    }

}
