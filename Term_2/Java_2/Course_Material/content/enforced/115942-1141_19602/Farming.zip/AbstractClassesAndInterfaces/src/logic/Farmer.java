/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

import logic.interfaces.*;

/**
 *
 * @author Mats Swan
 */
public abstract class Farmer implements WeatherReport {
    private String name;
    private boolean married;
    private Farm farm; // aggregation relationship:  a Farmer must have a Farm

    public abstract void harvest() ;
    public abstract void water() ;

    public Farm getFarm() {
        return farm;
    }

    public void setFarm(Farm farm) {
        this.farm = farm;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isMarried() {
        return married;
    }

    public void setMarried(boolean married) {
        this.married = married;
    }
    
}
