/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class VegetableFarmer extends ProduceFarmer {

    @Override
    public void sunny() {
        System.out.println("VegetableFarmer >>> It's sunny, good: veggies like sun");
    }

    @Override
    public void rain() {
        System.out.println("VegetableFarmer >>> It's raining, good: veggies like rain");
    }

    @Override
    public void snow() {
        System.out.println("VegetableFarmer >>> Oh no!  It's snowing, hope the veggies don't freeze");
    }

    @Override
    public void frost() {
        System.out.println("VegetableFarmer >>> Oh no!  It's cold, hope the veggies don't freeze");
    }

    @Override
    public void hot() {
        System.out.println("VegetableFarmer >>> It's hot, better make sure the veggies have enough water");
    }
    
}
