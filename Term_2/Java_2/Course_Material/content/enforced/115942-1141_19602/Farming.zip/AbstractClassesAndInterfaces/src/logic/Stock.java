/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class Stock extends Farm {
    private boolean stable;
    private boolean animalPen;
    private boolean freeRange;

    public boolean hasStable() {
        return stable;
    }

    public void setStable(boolean stable) {
        this.stable = stable;
    }

    public boolean hasAnimalPen() {
        return animalPen;
    }

    public void setAnimalPen(boolean pen) {
        this.animalPen = pen;
    }

    public boolean isFreeRange() {
        return freeRange;
    }

    public void setFreeRange(boolean freeRange) {
        this.freeRange = freeRange;
    }
    
}
