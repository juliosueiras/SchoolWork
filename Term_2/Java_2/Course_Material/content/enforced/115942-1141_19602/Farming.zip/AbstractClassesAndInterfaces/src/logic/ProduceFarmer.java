/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 * I chose to make ProduceFarmer abstract, too.  When you're a ProduceFarmer, 
 * you must harvest a specific type of produce, like fruit or vegetable.
 * 
 * @author Mats Swan
 */
public abstract class ProduceFarmer extends Farmer {

    /**
     * For the most part, produce farmers harvest their crops in the same way:
     * by picking it.  This will be the default harvest method for all produce 
     * farmers.  
     * Specific farmers, like CornFarmers, can override this method.
     */
    @Override
    public void harvest() {
        System.out.println("ProduceFarmer >>> I'm Produce Farmer " + getName() + ". I harvest my crop by picking it");
    }

    /** 
     * For the most part, again, produce farmers water their crops in the same way:
     * spraying them with water.  this will be the default water method for all
     * produce farmers.
     */
    @Override
    public void water() {
        System.out.println("ProduceFarmer >>> I'm a Produce Farmer " + getName() +". I water my crops by spraying them with water");
    }

    @Override
    public void sunny() {
        System.out.println("ProduceFarmer >>> It's sunny, good: the plants likes sun");
    }

    @Override
    public void rain() {
        System.out.println("ProduceFarmer >>> It's raining, good: the plants like rain");
    }

    @Override
    public void snow() {
        System.out.println("ProduceFarmer >>> Oh no!  It's snowing, hope the plants don't freeze");
    }

    @Override
    public void frost() {
        System.out.println("ProduceFarmer >>> Oh no! It's cold, hope the plants don't freeze");
    }

    @Override
    public void hot() {
        System.out.println("ProduceFarmer >>> It's hot, better make sure the plants keep hydrated");
    }

    
}
