/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class ChickenFarmer extends LivestockFarmer {

    @Override
    public void harvest() {
        System.out.println("ChickenFarmer >>> I'm a Chicken Farmer.  I harvest my animals by collecting eggs");
    }

    // The following methods are implemented from the WeatherReport interface
    // WeatherReport was implemented in the abstract Farmer class, but
    // because both Farmer and Livestock Farmer were abstract, I didn't need 
    // to create concrete implementations.  I must in this class.
    @Override
    public void sunny() {
        System.out.println("ChickenFarmer >>> It's sunny, let the chickens run outside (<-- ChickenFarmer)");
    }

    @Override
    public void rain() {
        System.out.println("ChickenFarmer >>> It's raining, leave the coop door open so the chickens can go inside (<-- ChickenFarmer)");
    }

    @Override
    public void snow() {
        System.out.println("ChickenFarmer >>> It's snowing, close the door and turn up the heat in the coop (<-- ChickenFarmer)");
    }

    @Override
    public void frost() {
        System.out.println("ChickenFarmer >>> It's cold, close the door and turn up the heat in the coop (<-- ChickenFarmer)");
    }

    @Override
    public void hot() {
        System.out.println("ChickenFarmer >>> It's hot, open the coop door and turn on a fan (<-- ChickenFarmer)");
    }

    
    
}
