/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

/**
 *
 * @author Mats Swan
 */
public class MushroomFarmer extends VegetableFarmer {

    public void shovelPoop() {
        System.out.println("MushroomFarmer >>> Mmmmm.  Poop.");
    }

    @Override
    public void water() {
        System.out.println("MushroomFarmer >>> I'm a mushroom farmer.  I don't need to water mushrooms, really, just keep them moist.");
    }

    @Override
    public void hot() {
        System.out.println("MushroomFarmer >>> It's hot: better cool down the mushrooms ");
    }

    @Override
    public void frost() {
        System.out.println("MushroomFarmer >>> It's cold, better raise the interior temperature and check humidity");
    }

    @Override
    public void snow() {
        System.out.println("MushroomFarmer >>> It's snowing, better raise the interior temperature and check humidity ");
    }

    @Override
    public void rain() {
        System.out.println("MushroomFarmer >>> It's raining... so what? My mushrooms grow indoors");
    }

    @Override
    public void sunny() {
        System.out.println("MushroomFarmer >>> It's sunny... so what? My mushrooms grow indoors");
    }

}
