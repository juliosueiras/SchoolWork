/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class StrawberryFarmer extends FruitFarmer {
    public void layStraw() {
        System.out.println("StrawberryFarmer >>> I'm putting straw around the berries");
    }

    @Override
    public void hot() {
        System.out.println("StrawberryFarmer >>> It's hot, better spread some extra straw around the berries");
        layStraw();
    }
    
}
