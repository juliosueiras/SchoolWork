/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package runtime;

import logic.*;

/**
 *
 * @author Mats Swan
 */
public class Launch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // replace StrawberryFarmer with other types, like Chicken and Mushroom
        Farmer matt = new MushroomFarmer();
        matt.setName("Matt");

        // These are implementations of abstract methods from abstract Farmer class
        System.out.println("-----------abstract methods from Farmer--------------");
        matt.water();
        matt.harvest();
        
        // These are implementations of methods from WeatherReport interface
        System.out.println("-----------abstract methods from WeatherReport interface--------------");
        matt.frost();
        matt.sunny();
        matt.hot();
        matt.snow();
        matt.rain();
        
    }

    
}
