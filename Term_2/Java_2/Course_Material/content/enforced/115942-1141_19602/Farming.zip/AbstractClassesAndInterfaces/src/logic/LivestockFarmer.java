/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

/**
 *
 * @author Mats Swan
 */
public abstract class LivestockFarmer extends Farmer {

    /**
     * The constructor for a LivestockFarmer will indicate that the farmer has stock
     * not a crop, like produce farmers do.
     */
    public LivestockFarmer() {
        setFarm(new Stock());
    }

    // LivestockFarmer is abstract and does not implement the abstract harvest method
    
    @Override
    public void water() {
        System.out.println("LivestockFarmer >>> I'm Farmer " + getName() + ".  I water my animals by filling their trough.");
    }

}
