/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic.interfaces;

/**
 * The hiring interface can be used by businesses to hire contract, F/T,
 * P/T or seasonal employees.
 * 
 * @author Mats Swan
 * @version 1.0
 * @since 22-JAN-14
 */
public interface Hiring {
    public void hireContractor();
    public void hireSeasonalLabour();
    public void hireFulltime();
    public void hireParttime();
}
