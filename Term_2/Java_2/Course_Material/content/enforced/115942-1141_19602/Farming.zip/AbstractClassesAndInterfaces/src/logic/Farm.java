/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 * Farmers must have land that they use to grow and maintain their product.  
 * The Farm class refers to this parcel of land.
 * 
 * @author Mats Swan
 * @since 22-JAN-14
 * @see Farmer
 */
public class Farm {
    private double acreage;
    private String farmName;
    private boolean barn;

    /**
     * Acreage defines the size of the farm, measured in acres
    */
    public double getAcreage() {
        return acreage;
    }

    public void setAcreage(double acreage) {
        this.acreage = acreage;
    }

    /**
     * A farm may have an estate name, such as "Breezy Acres" or the "Bar-K Ranch"
     */
    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    /**
     * Some farms have a barn
     */
    public boolean hasBarn() {
        return barn;
    }

    public void setHasBarn(boolean barn) {
        this.barn = barn;
    }
    
}
