/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import java.util.Scanner;

/**
 * This class tests String and Wrapper concepts which we discussed in class
 *
 * @author Mats Swan
 * @since 13-JAN-14
 * @see Launch
 */
public class ScrabbleTest {

    /**
     * This method accepts two Strings as input, examines where they can
     * intersect, as they would on a Scrabble board, then prints the words as if
     * they were placed horizontally and vertically in Scrabble.
     *
     * @since 13-JAN-14
     */
    public void run() {
        Scanner input = new Scanner(System.in);
        String horizontalWord, verticalWord;

        // Let's assume the words do not intersect.
        // Set their intersection points at -1
        int horizontalIntersection = -1;
        int verticalIntersection = -1;

        System.out.print("Please type in your first word: ");
        horizontalWord = input.nextLine();

        System.out.print("Please type in your second word: ");
        verticalWord = input.nextLine();

        // Until you find an intersection point, step through each letter in the 
        // horizontal word.  Compare that letter to each letter of the vertical
        // word.  If you find that they match, save the point of their intersection
        for (int i = 0; i < horizontalWord.length() && (verticalIntersection < 0); i++) {  // String convenience method: length()
            for (int j = 0; j < verticalWord.length(); j++) {
                Character letterInWordOne = new Character(horizontalWord.charAt(i));        // String convenience method: charAt()
                Character letterInWordTwo = new Character(verticalWord.charAt(j));          // Character wrapper class

                if (letterInWordOne.equals(letterInWordTwo)) {                              // Use the equals() method of the wrapper
                    horizontalIntersection = i;
                    verticalIntersection = j;
                    break;
                }
            }
        }

        // If there is no intersection
        if (horizontalIntersection == -1 || verticalIntersection == -1) {
            System.out.println("==> I'm sorry, those two words do not intersect");
            System.exit(1);
        }

        // Print the words vertically and horizontally
        for (int x = 0; x < verticalIntersection; x++) {
            for (int y = 0; y < horizontalIntersection; y++) {
                System.out.print(" ");
            }
            System.out.println(verticalWord.charAt(x));
        }
        System.out.println(horizontalWord);
        for (int x = verticalIntersection + 1; x < verticalWord.length(); x++) {
            for (int y = 0; y < horizontalIntersection; y++) {
                System.out.print(" ");
            }
            System.out.println(verticalWord.charAt(x));
        }
    }
}
