/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class WrapperTest {
    
    public void run() {
        int age = 45;
        double weight = 195.5;
        String name = "Mats Swan";
        char middleInitial = 'E';
        boolean isStudent = false;
        
        Integer iAge = new Integer(age);
        Double dWeight = new Double(weight);
        Character cMiddleInitial = null ;
        Boolean bIsStudent = new Boolean(isStudent);
        
        cMiddleInitial.charValue();
        iAge.intValue();
        dWeight.doubleValue();
        bIsStudent.booleanValue();
               
        String sAge = "45";
        
        Integer.parseInt(sAge);
        Double.parseDouble(sAge);
        Float.parseFloat(sAge);
        Character.isDigit(middleInitial);
        
//        String.v
        
        System.out.println("The sum of these two is: " + age);
    }
}
