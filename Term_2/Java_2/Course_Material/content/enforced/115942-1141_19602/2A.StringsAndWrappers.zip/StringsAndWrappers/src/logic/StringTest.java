/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 * This class is going to test the features of Strings
 * 
 * @author Mats Swan
 * @since 13-JAN-14
 * @see Launch
 */
public class StringTest {
    /**
     * This method runs the StringTest class
     * 
     * @since 13-JAN-14
     * @version 1.0
     */
    public void run() {
        String sPlaceOfBirth = new String("erie");
        String sResidence = new String("ERIE");
        int iAge;
        double dWeight;
        
        
        
        String sWelcomeMessage = "Welcome to Java Object Oriented Programming";
        int sPositionOfJ = sWelcomeMessage.indexOf("J");
        
        String justJava = sWelcomeMessage.substring(sPositionOfJ);
        
      
       
        
//        System.out.println("The value of areEqual is: " + areEqual);
        System.out.println("Convenience Method - substring - " + justJava);
    }
}
