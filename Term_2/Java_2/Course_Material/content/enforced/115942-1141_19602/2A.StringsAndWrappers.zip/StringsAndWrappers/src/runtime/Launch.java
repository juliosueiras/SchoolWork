/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package runtime;

import logic.*;

/**
 *
 * @author Mats Swan
 */
public class Launch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        StringTest test = new StringTest();
//        WrapperTest test = new WrapperTest();
        ScrabbleTest test = new ScrabbleTest();
        test.run();
    }
    
}
