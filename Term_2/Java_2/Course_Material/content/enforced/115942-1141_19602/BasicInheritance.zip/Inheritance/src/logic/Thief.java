/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class Thief extends DnDCharacter {

    public Thief(int strength, int intelligence, int wisdom, int dexterity, int constitution, int charisma) {
        super(strength, intelligence, wisdom, dexterity, constitution, charisma);
    }
    
    public void steal() {
        System.out.println("==> Yoink!  Stolen");
    }
    
}
