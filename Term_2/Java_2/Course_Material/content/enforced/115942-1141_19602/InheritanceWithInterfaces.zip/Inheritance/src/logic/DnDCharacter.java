/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

/**
 *
 * @author Mats Swan
 */
public abstract class DnDCharacter {

    private int strength, intelligence, wisdom, dexterity, constitution, charisma;

    public DnDCharacter(int strength, int intelligence, int wisdom, int dexterity, int constitution, int charisma) {
        setStrength(strength);
        setIntelligence(intelligence);
        setWisdom(wisdom);
        setDexterity(dexterity);
        setConstitution(constitution);
        setCharisma(charisma);
    }

    public abstract void fightMonster();
    
    public int getStrength() {
        return strength;
    }
    
    

    public void setStrength(int strength) {
        if (strength < 3) {
            throw new InvalidCharacterAttributeException(strength, 
                    "Value for strength cannot be less than 3");
        } else if (strength > 18) {
            throw new InvalidCharacterAttributeException(strength, 
                    "Value for strength cannot exceed 18");
        } else {
            this.strength = strength;
        }
    }

    public int getIntelligence() {
        return intelligence;
    }

    public void setIntelligence(int intelligence) {
        if (intelligence < 3) {
            throw new InvalidCharacterAttributeException(intelligence, 
                    "Value for intelligence cannot be less than 3");
        } else if (intelligence > 18) {
            throw new InvalidCharacterAttributeException(intelligence, 
                    "Value for intelligence cannot exceed 18");
        } else {
            this.intelligence = intelligence;
        }
    }

    public int getWisdom() {
        return wisdom;
    }

    public void setWisdom(int wisdom) {
        if (wisdom < 3) {
            throw new InvalidCharacterAttributeException(wisdom, 
                    "Value for wisdom cannot be less than 3");
        } else if (wisdom > 18) {
            throw new InvalidCharacterAttributeException(wisdom, 
                    "Value for wisdom cannot exceed 18");
        } else {
            this.wisdom = wisdom;
        }
    }

    public int getDexterity() {
        return dexterity;
    }

    public void setDexterity(int dexterity) {
        if (dexterity < 3) {
            throw new InvalidCharacterAttributeException(dexterity, 
                    "Value for dexterity cannot be less than 3");
        } else if (dexterity > 18) {
            throw new InvalidCharacterAttributeException(dexterity, 
                    "Value for dexterity cannot exceed 18");
        } else {
            this.dexterity = dexterity;
        }
    }

    public int getConstitution() {
        return constitution;
    }

    public void setConstitution(int constitution) {
        if (constitution < 3) {
            throw new InvalidCharacterAttributeException(constitution, 
                    "Value for constitution cannot be less than 3");
        } else if (constitution > 18) {
            throw new InvalidCharacterAttributeException(constitution, 
                    "Value for constitution cannot exceed 18");
        } else {
            this.constitution = constitution;
        }
    }

    public int getCharisma() {
        return charisma;
    }

    public void setCharisma(int charisma) {
        if (charisma < 3) {
            throw new InvalidCharacterAttributeException(charisma, 
                    "Value for charisma cannot be less than 3");
        } else if (charisma > 18) {
            throw new InvalidCharacterAttributeException(charisma, 
                    "Value for charisma cannot exceed 18");
        } else {
            this.charisma = charisma;
        }
    }

    @Override
    public String toString() {
        return "Strength: " + getStrength() + "\n"
                + "Intelligence " + getIntelligence() + "\n"
                + "Wisdom: " + getWisdom() + "\n"
                + "Dexterity: " + getDexterity() + "\n"
                + "Constitution: " + getConstitution() + "\n"
                + "Charisma: " + getCharisma();

    }

}
