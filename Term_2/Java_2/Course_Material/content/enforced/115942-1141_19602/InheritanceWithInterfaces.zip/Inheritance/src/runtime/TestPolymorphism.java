/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package runtime;

import logic.*;

/**
 *
 * @author Mats Swan
 */
public class TestPolymorphism {
  public static void main(String[] args) {
      KnifeExpert matt =  new Ranger();
//      matt.fightMonster();
      matt.stab();
      matt.throwKnife();
      matt.jimmy();
      ((Ranger)matt).heal();
  }  
}
