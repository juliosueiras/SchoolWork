/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runtime;

import java.util.InputMismatchException;
import java.util.Scanner;
import logic.*;

/**
 * The Launch class is going to run the sample program.
 *
 * @author Mats Swan
 * @since 15-JAN-14
 * @version 1.1
 */
public class Launch {

    /**
     * The main method will prompt the user for a new character's attributes and
     * create a new D&D character based on those attributes.
     *
     * @param args the command line arguments
     * @since 15-JAN-14
     * @see DnDCharacter, InvalidCharacterAttributeException
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean validValue = false, pickAnotherClass = false;
        int[] characterAttributes = new int[6];

        System.out.println("Dungeons & Dragons Character Creator");
        System.out.println("=====================================");

        // Use a for loop to read in the six values for basic character traits
        for (int i = 0; i < characterAttributes.length; i++) {
            do {
                System.out.print("Please enter a value between 3 - 18: ");
                try {
                    characterAttributes[i] = input.nextInt();                   // push each value into an array
                    validValue = true;
                } catch (InputMismatchException imx) {
                    System.err.println(" ==> Please use only integer values");
                }
                input.nextLine();                                               // flush the buffer
            } while (!validValue);
        }

        DnDCharacter myCharacter = null;                                        // Initialize a generic character
        do {
            System.out.println("What type of character class would you like?");
            System.out.println("\t(F)ighter");
            System.out.println("\t(R)anger");
            System.out.println("\t(P)aladin");

            System.out.println("\t(M)agic-User");
            System.out.println("\t(I)llusionist");
            System.out.println("\t(N)ecromancer");

            System.out.println("\t(C)leric");
            System.out.println("\t(D)ruid");

            System.out.println("\t(T)hief");
            System.out.println("\t(A)ssassin");
            System.out.print("? >");

//            String userInput = input.nextLine();
//            String userInputToLowerCase = userInput.toLowerCase();
//            Character userChoice = userInputToLowerCase.charAt(0);
            Character choice = input.nextLine().toLowerCase().charAt(0);        // String manipulation - look at first letter only
            try {
                switch (choice) {
                    case 'f':
                        System.out.println("\nYou chose the FIGHTER class\nFighters go...");
                        myCharacter = new Fighter( // examine the constructor and
                                characterAttributes[0], // setters for this class: if the
                                characterAttributes[1], // value is invalid (ie, < 3 || > 18)
                                characterAttributes[2], // then our custom exception is thrown
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);

                        ((Fighter) myCharacter).pummel();
                        break;
                    case 'r':
                        System.out.println("\nYou chose the RANGER class\nRangers go...");
                        myCharacter = new Ranger( // also look at assignment
                                characterAttributes[0], // a specific class (Ranger) is set to 
                                characterAttributes[1], // the generic DnDCharacter variable
                                characterAttributes[2], // This is called POLYMORPHISM (more later)
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Ranger) myCharacter).pummel();                        // defined in Fighter class
                        ((Ranger) myCharacter).track();                         // pummel is used by INHERITANCE
                        break;
                    case 'p':
                        System.out.println("\nYou chose the PALADIN class\nPaladins go...");
                        myCharacter = new Paladin(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Paladin) myCharacter).pummel();
                        ((Paladin) myCharacter).heal();
                        break;
                    case 'm':
                        System.out.println("\nYou chose the MAGIC-USER class\nMagic-Users go...");
                        myCharacter = new MagicUser(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((MagicUser) myCharacter).castSpell();
                        break;
                    case 'i':
                        System.out.println("\nYou chose the ILLUSIONIST class\nIllusionists go...");
                        myCharacter = new Illusionist(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Illusionist) myCharacter).castSpell();                // defined in parent class
                        ((Illusionist) myCharacter).deceive();
                        break;
                    case 'n':
                        System.out.println("\nYou chose the NECROMANCER class\nNecromancers go...");
                        myCharacter = new Necromancer(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Necromancer) myCharacter).castSpell();
                        ((Necromancer) myCharacter).raiseDead();
                        break;
                    case 'c':
                        System.out.println("\nYou chose the CLERIC class\nClerics go...");
                        myCharacter = new Cleric(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Cleric) myCharacter).turnUndead();
                        break;
                    case 'd':
                        System.out.println("\nYou chose the DRUID class\nDruids go...");
                        myCharacter = new Druid(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Druid) myCharacter).turnUndead();
                        ((Druid) myCharacter).talkToAnimals();
                        break;
                    case 't':
                        System.out.println("\nYou chose the THIEF class\nThieves go...");
                        myCharacter = new Thief(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Thief) myCharacter).steal();
                        break;
                    case 'a':
                        System.out.println("\nYou chose the ASSASSIN class\nAssassins go...");
                        myCharacter = new Assassin(
                                characterAttributes[0],
                                characterAttributes[1],
                                characterAttributes[2],
                                characterAttributes[3],
                                characterAttributes[4],
                                characterAttributes[5]);
                        ((Assassin) myCharacter).steal();
                        ((Assassin) myCharacter).assassinate();
                        break;
                    default:
                        System.out.println("Sorry!  You chose an invalid class");
                        break;
                }
            } catch (InvalidCharacterAttributeException icax) {                 // custom exception caught from constructor
                System.err.println(" ==> Invalid attribute: "
                        + icax.getMessage());
                System.err.println(" ==> Exiting...");                          // do not continue
                System.exit(1);
            }
            System.out.print("\nWould you like to try another class? (y/n) ");
            pickAnotherClass = input.nextLine().startsWith("y");                // more efficient
        } while (pickAnotherClass);
    }
}
