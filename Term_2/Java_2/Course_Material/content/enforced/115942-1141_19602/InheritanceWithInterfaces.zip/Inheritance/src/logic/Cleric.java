/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author Mats Swan
 */
public class Cleric extends DnDCharacter implements Healing {

    public Cleric(int strength, int intelligence, int wisdom, int dexterity, int constitution, int charisma) {
        super(strength, intelligence, wisdom, dexterity, constitution, charisma);
    }
    
    public void turnUndead() {
        System.out.println("==> Begone!  Nasty undead");
    }

    @Override
    public void fightMonster() {
        System.out.println(">>> I exorcise thee!");
    }

    @Override
    public void heal() {
        System.out.println(">>> You are cured, my son");
    }

    
}
