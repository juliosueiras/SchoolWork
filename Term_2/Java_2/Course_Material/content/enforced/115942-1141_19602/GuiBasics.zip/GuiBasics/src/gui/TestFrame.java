/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

import java.awt.FlowLayout;
import java.awt.HeadlessException;
import javax.swing.*;

/**
 *
 * @author Mats Swan
 */
public class TestFrame extends JFrame {

    public TestFrame() throws HeadlessException {
        super();
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 1, 1));
        this.setVisible(true);
        this.setSize(500, 150);
        this.setTitle("Address Frame");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        JLabel lblStreet = new JLabel("Street:");
        JLabel lblCity = new JLabel("City:");
        String[] provinces = {"Ontario", "Quebec", "Alberta"};
        JComboBox lblProvince = new JComboBox(provinces);
        
        JTextField txtStreet = new JTextField(25);
        JTextField txtCity = new JTextField(25);
        JTextField txtProvince = new JTextField(25);
        
        JButton pbOK = new JButton("OK");
        JButton pbCancel = new JButton("Cancel");

        add(lblStreet);
        add(txtStreet);
        add(lblCity);
        add(txtCity);
        add(lblProvince);
        add(txtProvince);
        add(pbOK);
        add(pbCancel);
        
//        pack();
    }
    
}
