
function translateToCanadianese()
{
    var userText = prompt('Please enter a sentence.');
    userText = userText.split(' ');

    for (var i = 0; i < userText.length; i++)
    {
        userText[i] = userText[i] + 'eh';
    }

    printOutText(userText);
}

function makeSHERISayVisible()
{
    document.getElementById('SHERISay').style.visibility = 'visible';
}

function theCoinGame()
{
    makeSHERISayVisible();
    var resultHTML = document.getElementById('result');
    var piggyBanks = [0, 0, 0, 0, 0, 0, 0];

    for (var i = 0; i < 7; i++)
    {
        piggyBanks[Math.floor(Math.random() * 7)] += 1;
    }

    var userChoice;

    resultHTML.innerHTML = '';

    for (var i = 0; i < 2; i++)
    {
        do
        {
            userChoice = prompt('Please select a piggy bank(can\'t be the same, 1 - 7)');

            if (isNaN(userChoice))
            {
                alert('Please enter a number only');
            }
            else if (piggyBanks[userChoice - 1] === '')
            {
                alert('This piggy banks had been selected');
            }
            else if (userChoice > 7 || userChoice <= 0)
            {
                alert('The number have to be between 1 to 7');
            }

        } while ((isNaN(userChoice)) || (piggyBanks[userChoice - 1] === '') || (userChoice > 7 || userChoice <= 0));

        resultHTML.innerHTML += 'You select piggy bank ' + userChoice + ' and it have ' + piggyBanks[userChoice - 1] + ' coins<br/>';

        piggyBanks[userChoice - 1] = '';
    }
}

function encodeUserText()
{
    makeSHERISayVisible();
    var userText = prompt('Please enter a sentence.');
    userText = userText.split(' ');

    for (var i = 0; i < userText.length; i++)
    {
        userText[i] = userText[i].charAt(userText[i].length - 1) + userText[i].substring(0, userText[i].length - 1);
    }

    printOutText(userText);
}

function decodeUserText()
{
    makeSHERISayVisible();

    var userText = prompt('Please enter a sentence.');
    userText = userText.split(' ');

    for (var i = 0; i < userText.length; i++)
    {
        userText[i] = userText[i].substring(1, userText[i].length) + userText[i].charAt(0);
    }

    printOutText(userText);
}

function changeBackground(requestedBackground, restoreVisibleOrNot)
{
    document.body.style.backgroundColor = requestedBackground;
    document.getElementById('restoreBackgroundButton').style.visibility = restoreVisibleOrNot;
}

function changeButtonBackground(requestedBackground, restoreVisibleOrNot)
{
    var buttonList = document.getElementsByTagName('button');

    for(var i = 0; i < buttonList.length; i++)
    {
        buttonList.item(i).style.background = requestedBackground;
    }

    document.getElementById('restoreButtonBackgroundButton').style.visibility = restoreVisibleOrNot;
}

function restoreBackground()
{
    changeBackground('white','hidden');
}

function restoreButtonBackground()
{
    changeButtonBackground('buttonFace','hidden');
}

function printOutText(text)
{
    var resultHTML = document.getElementById('result');
    resultHTML.innerHTML = '';
    for (var i = 0; i < text.length; i++)
    {
        resultHTML.innerHTML += text[i] + ' ';
    }
}



